module.exports = function(req, res){
	console.log(req.method, ' - ', req.url);
};